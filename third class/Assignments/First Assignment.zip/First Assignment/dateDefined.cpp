// Bablu Banik
// First Assignment


#include <iostream>

using namespace std;

#include "Date.h"



//no-argument constructor :
Date::Date() : month(0), day(0), year(0){}

Date::Date(int& m, int& d, int& y)
{
	month = m;
	day = d;
	year = y;

}



void Date::displayDate()


{

	const string monthStr[] =   //alternative:  const char monthStr[] [15]=
	{ "January", "February", "March", "April", "May", "June",
	"July", "August", "September", "October", "November",
	"December" };

	const string monthStrAbbrev[] =  //not strictly necessary, but helpful
	{ "jan", "feb", "mar", "apr", "may", "jun",
	"jul", "aug", "sep", "oct", "nov",
	"dec" };

	const int startYear = 1900;
	const int endYear = 2020;

	const int monthDays[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };


	if ((day == monthDays[month - 1] || day < monthDays[month - 1]) && (year >= startYear && year <= endYear) && (month <= 12))
	{
		cout << month << "/" << day << "/" << year << endl;
		cout << monthStr[month - 1] << " " << day << ", " << year << endl;
		cout << year << "-" << month << "-" << day << endl;
		cout << year << "-" << monthStrAbbrev[month - 1] << "-" << day << endl;
	}

	else
	{
		cout << 1 << "/" << 1 << "/" << 2001 << endl;
		cout << monthStr[0] << " " << 1 << ", " << 2001 << endl;
		cout << 2001 << "-" << 1 << "-" << 1 << endl;
		cout << 2001 << "-" << monthStrAbbrev[0] << "-" << 1 << endl;
	}
}